
  # Market

  This is a code bundle for Market. The original project is available at https://www.figma.com/design/yHiXNjfWRGbswgYXmrHPbW/Market.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  